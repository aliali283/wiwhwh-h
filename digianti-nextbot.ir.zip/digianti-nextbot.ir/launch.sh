#!/bin/bash

./tg -s bot.lua -p apimode --bot=610835478:AAFG6Jv_Py925e8hK4Y8VyGZyUHHcTdXVUc $@


